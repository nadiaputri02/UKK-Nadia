<?php
include("config.php");
$hasil = mysqli_query($connection, "SELECT * FROM pembayaran ORDER by id DESC");
?>
<html>
    <head>
        <title>Data Pembayaran</title>
    </head>
    <body>
        <div style="
        margin-top: 10px;
        margin-bottom: 10px;
        border: 2px solid black;
        width: 30%;
        text-align: center;
        color: black;
        padding: 5px;
        float: right;">
            <a href="tambahpembayaran.php" style="text-decoration: none; color: black;">
                Tambah Data Pembayaran
            </a>
        </div>
        <table style="width: 100%;" border="1">
            <thead>
                <tr>
                    <th>Id Pembayaran</th>
                    <th>Id Petugas</th>
                    <th>NIS</th>
                    <th>Tanggal Bayar</th>
                    <th>Jumlah Bayar</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                while($pembayaran = mysqli_fetch_array($hasil))
                {
                    echo "<tr>";
                    echo "<td>".$pembayaran['id_pembayaran']."</td>";
                    echo "<td>".$pembayaran['id_petugas']."</td>";
                    echo "<td>".$pembayaran['nis']."</td>";
                    echo "<td>".$pembayaran['tgl_bayar']."</td>";
                    echo "<td>".$pembayaran['jumlah_bayar']."</td>";
                    echo "<td>
                    <a href='edit.php?id=$pembayaran[id]'>Edit</a> | <a href='delete.php?id=$pembayaran[id]'>Delete</a></td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
    </body>
</html>