<html>
    <head>
        <title>Tambahkan Data Pembayaran</title>
    </head>
<body>
        <h2>
            Tambah Daftar Pembayaran
        </h2>
        <form action="tambahpembayaran.php" method="post" name="form1">
            <div style="width: 100%; display: block; margin-top: 10px; margin-bottom: 10px;">
                <div style="margin-bottom: 5px;">
                    <label>
                        Id Pembayaran :
                    </label>
                </div>
                <input type="text" style="width: 100%; border: 2px solid black; border-radius: 5px;" name="id_pembayaran">
            </div>
            <div style="width: 100%; display: block; margin-top: 10px; margin-bottom: 10px;">
                <div style="margin-bottom: 5px;">
                    <label>
                        Id Petugas :
                    </label>
                </div>
                <input type="text" style="width: 100%; border: 2px solid black; border-radius: 5px;" name="id_petugas">
            </div>
            <div style="width: 100%; display: block; margin-top: 10px; margin-bottom: 10px;">
                <div style="margin-bottom: 5px;">
                    <label>
                        NIS :
                    </label>
                </div>
                <input type="text" style="width: 100%; border: 2px solid black; border-radius: 5px;" name="nis">
            </div>
            <div style="width: 100%; display: block; margin-top: 10px; margin-bottom: 10px;">
                <div style="margin-bottom: 5px;">
                    <label>
                        Tanggal Bayar :
                    </label>
                </div>
                <input type="date" style="width: 100%; border: 2px solid black; border-radius: 5px;" name="tanggal_bayar">
            </div>
            <div style="width: 100%; display: block; margin-top: 10px; margin-bottom: 10px;">
                <div style="margin-bottom: 5px;">
                    <label>
                        Jumlah Bayar :
                    </label>
                </div>
                <input type="selection" style="width: 100%; border: 2px solid black; border-radius: 5px;" name="jumlah_bayar">
            </div>
            <div>
                <input type="submit" name="Submit" style="background: blue; border-radius: 5px; padding: 5px; border: 2px solid blue; color: white;" value="Tambahkan">
                <a href='index.html' style="border: 2px solid red; padding: 5px; border-radius: 5px; color: white; background-color: red; text-decoration: none;">Cancel</a>
            </div>
        </form>
        <?php
        // Chek apalah form sudah tersubmit, insert data dari tabel pembayaran
        if(isset($_POST['Submit']))
        {
            $id_pembayaran = $_POST['id_pembayaran'];
            $id_petugas = $_POST['id_petugas'];
            $nis = $_POST['nis'];
            $tgl_bayar = $_POST['tgl_bayar'];
            $jumlah_bayar = $_POST['jumlah_bayar'];
            include("config.php");
            $hasil = mysqli_query($connection, "INSERT INTO pembayaran (id_pembayaran,id_petugas,nis,tgl_bayar,jumlah_bayar) VALUES('$id_pembayaran', '$id_petugas', '$nis', '$tgl_bayar', '$jumlah_bayar') ");
// menampilkan pesan ketika berhasil di tambahkan
            echo "Data pembayaran Berhasil DiTambahkan. <a href='index.html'>Data Pembayaran</a>";
        }
        ?>
    </body>
</html>
